/**
 * Gaby Buchnic & Oved Shalem
 *
 */
package Game;

import java.awt.EventQueue;

public class index {

	public static void main(String[] args) {
	
		EventQueue.invokeLater(new Runnable() { 		//Enable calculation while program running
			public void run() {
				try {
					PanelGame frame = new PanelGame(); 	//Create new panel game 
					frame.setVisible(true); 			//Set frame visible
				}
				catch (Exception e) { 					//Case unable to create frame 
					e.printStackTrace(); 				//Print error Exception
				}
			}
		});
	}

}
