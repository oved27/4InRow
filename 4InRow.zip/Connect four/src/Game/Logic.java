/**
 * Gaby Buchnic & Oved Shalem
 *
 */
package Game;

//import javax.naming.CommunicationException;

public class Logic {
	private Data d;

	private int tmp[][];  									//Temporary matrix
	private int arrayMax1[];               					//Array that hold all the user sequence
	private int arrayMax2[];           					    //Array that hold all the computer sequence
	private int arrayPlace[];        						//Matrix that hold the highest coin in each column

	public Logic(Data d) {  								//Copy constructor 
		this.d = d;  										//Copy the given to the d matrix
		tmp = d.getMatrix(); 								//Copy the d matrix to tmp
		setArray();                      				  	//Set size to all arrays according to the given size 
	}

	public Logic() {   										//Constructor for new matrix
		this.d = new Data();  								//Create the d matrix object
		tmp = d.getMatrix(); 								//Copy the d matrix to tmp
		setArray();    				        				//Set size to all arrays according to the given size 
	}
	//Method for get the highest sequence
	public int getStep() {  
		int max2 = -1, id2 = -1, max1 = -1, id1 = -1; 		//Initialize all counter
		for (int i = 0; i < arrayMax2.length; i++) { 		//Checking highest sequence
			//Computer
			if (max2 < arrayMax2[i]) { 						//Check if current sequence bigger then previous 
				id2 = i; 									//Update the index column
				max2 = arrayMax2[i]; 						//Update max1 
			}
            //User
			if (max1 < arrayMax1[i]) { 						//Check if current sequence bigger then previous
				id1 = i;  									//Update the index column	
				max1 = arrayMax1[i]; 						//Update max2 
			}
		}
		if (max1 >= 2 && max1 > max2)  						//Defense: case user have option to create sequence win
			return id1; 									//Return user's column to 
		else if (max2 >= 3) 								//attack:  Case computer have option to increase his sequence
			return id2; 									//Return number of column 
		else
			return getRandomStep();  						//Else try random step
	}
	//Method for set random step for the computer
	public int getRandomStep() { 
		int count; 
		int selectColumn = (int) (Math.random() * 7); 	//Get random cell 0-6
		for (count = 0; count < arrayMax2.length; count++) {  

			if (selectColumn == (arrayMax2.length-1)) { 	//case the chosen column is the last one
				selectColumn = 0;						//Set to col=0
			}
			else {										
				if (arrayMax2[selectColumn] != -1)	{	//Check if col is not full
					break;								//Then exit
				}
				selectColumn++;							//Case given col is full try next col
			}
		}
		if (count > arrayMax2.length)					//Check if can't find empty col
			return -1;									//Then return -1 
		return selectColumn;							//Return the chosen col to drop coin
	}

	public int getStepPlayer(int player) { 					//Replace player's turn
		if (player == 1) 									//Case user play
			player = 2;
		else  												//Case computer play
			player = 1;  
		return player;
	}

	//Method for check winner
	public int getWinner(int cols, int player) { 

		int result = checking(player, getRow(cols), cols); 	//Set the highest sequence for the given player
		if (result >= 3) {									//Case equal or above 3 then wins
			return player; 									//Return winner number (1-player 2-computer)
		}

		for(int i=0 ;i<arrayPlace.length; i++){				//Check if there more moves
			if(arrayPlace[i]!=-1){							//case find empty cell
				return 0;
			 
			}

		}
		 	return 3;										//Else no free cell
	}
	 //Method  for return row number according to highest coin in the column.
	public int getRow(int column) {
		for (int i = 0; i < d.getRows(); i++) {
			if (tmp[i][column] != 0)  						//Case cell is not empty
				return i; 									//Return number of row
		}
		return -1; 											//Case column is full of coins 
	}

	/******************************************************************/
	/******************************************************************/
	/******************************************************************/
	/******************************************************************/
	//Method set into arrayPlace the highest coin in each column of the matrix(Graph)
	public void initArrayPlace() {  

		for (int i = 0; i < d.getColumn(); i++) {  			//Run on all columns
			int counter = -1;  								//Reset columns counter
			for (int j = 0; j < d.getRows(); j++) { 		//Run on all rows
				if (tmp[j][i] != 0) 						//Case coin exist 
					break;									//Then break
				counter++; 									//Else continue to the next row 
			}
			arrayPlace[i] = counter; 						//Set the highest coin's place
		} 
	}
	//Method that receive player and pointer to the given matrix and initialize the matrix with the highest values
	public void initArrayMax(int player, int arr[]) { 
		for (int i = 0; i < arrayPlace.length; i++) {		//Run on all matrix
			arr[i] = checking(player, arrayPlace[i], i); 	//According to the highest coin given set the highest sequence value into the matrix  
		}
	}
	//Method for set the size of the arrays
	public void setArray() { 
		arrayMax2 = new int[d.getColumn()];					//Computer's array 
		arrayMax1 = new int[d.getColumn()];					//User's array
		arrayPlace = new int[d.getColumn()];				//Graph of highest coin in the  Matrix 
	}
    //Methods for get the arrays
	public int[] getArrayMax2() {
		return arrayMax2;
	}

	public int[] getArrayPlace() {
		return arrayPlace;
	}

	public int[] getArrayMax1() {
		return arrayMax1;
	}
    //Method for set array max1
	public void setArrayMax1(int[] arr) {
		arrayMax1 = arr;
	}

	
	/******************************************************************/
	/******************************************************************/
	/******************************************************************/
	/******************************************************************/

	//Method for Check the biggest sequential
	public int checking(int player, int rows, int column) {
		if (rows <= -1) 									//Check if the given column is full
			return -1; 

		int c = checkHorizon(player, rows, column); 		//Set the number of coins on the rows
		int t = checkVertical(player, rows, column); 		//Set the number of coins on the column
		if (c < t)  										//check which one is bigger rows / cols 
			c = t; 											//Set the bigger value to c
		t = checkDiagonal(player, rows, column);  			//Set the number of coins on the diagonals
		if (c < t)   										//Check which one is bigger c or diagonal 
			c = t;											//Set the bigger value to c 
		return c; 											//Return the bigger value
	}
	//Method for Check two diagonal for number of coins, return the bigger
	private int checkDiagonal(int player, int rows, int column) { 
		//Set the number of coins on the right diagonal
		int right = checkDiagonaltoRightDown(player, rows, column) + checkDiagonalToLeftUp(player, rows, column); 
		
		//Set the number of coins on the left diagonal
		int left = checkDiagonalToLeftDown(player, rows, column) + checkDiagonalToRightUp(player, rows, column); 
		if (right > left) 									//Check which diagonal is bigger 
			return right;
		return left;
	}
	
	//Method for checking sequential coins from the left up to the right bottom
	private int checkDiagonaltoRightDown(int player, int rows, int column) {
		int count = 0; 										//Index for number of coins
		for (int i = ++rows, j = ++column; i < d.getRows() && j < d.getColumn(); i++, j++) {
			if (tmp[i][j] != player) 						//If sequential break return false 
				break;
			else
				count++; 									//If sequential Continue update count
		}
		return count; 										//Return the total of sequential coins from current position +1 to right down
	}

	//Method for checking sequential coins from the right bottom to the left up
	private int checkDiagonalToLeftUp(int player, int rows, int column) {
		int count = 0; 										//index for number of coins
		for (int i = --rows, j = --column; i >= 0 && j >= 0; i--, j--) {
			if (tmp[i][j] != player) 						//If sequential break return false  
				break; 
			else
				count++; 									//If sequential Continue update count
		}
		return count;  										//Return the total of sequential coins from current position +1 to the left up
	}

	//Method for checking sequential coins from the up right to the left bottom
	private int checkDiagonalToLeftDown(int player, int rows, int column) {
		int count = 0; 										//Index for number of coins
		for (int i = ++rows, j = --column; i < d.getRows() && j >= 0; i++, j--) {
			if (tmp[i][j] != player) 						//If sequential break return false 
				break;
			else
				count++; 									//If sequential Continue update count
		}
		return count; 										//Return the total of sequential coins from current position +1 to the left bottom
	}

	//Method for checking sequential coins from the left bottom to the up right
	private int checkDiagonalToRightUp(int player, int rows, int column) {
		int count = 0; 										//index for number of coins
		for (int i = --rows, j = ++column; j < d.getRows() && i >= 0; i--, j++) {
			if (tmp[i][j] != player) 						//If sequential break return false 
				break;
			else
				count++; 									//If sequential Continue update count
		}
		return count;  										//Return the total of sequential coins from current position +1 to the up right corner
	}

	//Method for checking sequential coins Vertical
	private int checkVertical(int player, int rows, int column) {  
		int count = 0;  									//Index for number of coins
		for (int i = (rows + 1); i < d.getRows(); i++) {  	//Check from current position +1 to the bottom
			if (tmp[i][column] != player)					//If sequential break return false 
				break;
			else
				count++; 									//If sequential Continue update count
		}
		return count; 										//Return the total of sequential coins from current position +1 to the bottom
	}

	//Method for counting coins on the left and right sides
	private int checkHorizon(int player, int rows, int column) { 
		int right = checkHorizonRight(player, rows, column); 	//Set the number of coins from right
		int left = checkHorizonLeft(player, rows, column); 		//Set the number of coins from left
		return right + left; 									//Return the total number of sequential coins in the row

	}

	//Method for checking sequential coins to the right
	private int checkHorizonRight(int player, int rows, int column) {
		int count = 0;  									//Index for number of coins
		for (int i = ++column; i < d.getColumn(); i++) { 	//Check from current position +1 to the right
			if (tmp[rows][i] != player) 					//If sequential break return false 
				break;
			else
				count++;  									//If sequential Continue update count
		}
		return count; 										//Return the total of sequential coins on the right side
	}
	
	//Method for checking sequential coins to the left
	private int checkHorizonLeft(int player, int rows, int column) {
		int count = 0;  									//Index for number of coins
		for (int i = --column; i >= 0; i--) { 				//Check from current position +1 to the left
			if (tmp[rows][i] != player)  					//If sequential break return false  
				break;
			else
				count++; 									//If sequential Continue update count
		}
		return count; 										//Return the total of sequential coins on the left side
	}

}
