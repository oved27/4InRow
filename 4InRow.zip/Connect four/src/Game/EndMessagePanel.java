/**
 * Gaby Buchnic & Oved Shalem
 *
 */

package Game;

//import java.awt.BorderLayout;
//import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;

public class EndMessagePanel extends JFrame { 					//Design the player's win massage

private JPanel contentPane;  									//Create content pane
public EndMessagePanel(String msg) {  							//Receive win massage from PanelGame about the player who win
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 350, 255);
		contentPane = new JPanel(); 							//Create the object
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5)); 	//Set pane border 
		setContentPane(contentPane);  							//Send the win message to the content pane
		contentPane.setLayout(null); 							//Set the layout of the text 

		JLabel lblNewLabel = new JLabel("New label"); 			//Create new JLabel
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 13)); //Define the font of the label
		lblNewLabel.setBounds(73, 66, 250, 40); 				//Set text's  boundaries panel
		lblNewLabel.setText(msg); 								//Send the text to the Jlabel
		contentPane.add(lblNewLabel); 							//Add the Jlabel to the window 
	}
}
