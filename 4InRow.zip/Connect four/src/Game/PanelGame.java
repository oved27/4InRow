/**
 * Gaby Buchnic & Oved Shalem
 *
 */
package Game;

import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PanelGame extends JFrame {

	private JPanel contentPane; 						//Create content pane object 
	private int player; 								//User=1 Computer=2
	private JLabel[][] mtrxLabel; 						//Create label for coin holder
	boolean gameOn;										//Flag for keep on playing
	
	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */
	public PanelGame() {
		Data d = new Data();     						//Create new object from Data that create the matrix
		Logic log = new Logic(d); 						//Create new object that hold the matrix
		player = 1;  									//User play first 
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 385, 378);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		mtrxLabel = getMtrxLabels(d); 					//Put all icon in the labels in the matrix
		addToContentPane(d, log);
		gameOn =true;									//Reset keep on playing 

	}

	private void addToContentPane(Data objData, Logic log) {
		int sizeLabel = 40, space = 5; 						//Size of the label and space

		for (int i = 0, x = 30; i < objData.getColumn(); i++, x += (sizeLabel + space)) {
			contentPane.add(getButton(x, objData, log, i)); //Put the button on the board 
		}

		for (int i = 0; i < objData.getRows(); i++) { 
			for (int j = 0; j < objData.getColumn(); j++) {
				contentPane.add(mtrxLabel[i][j]); 			//Put the labels on the board 
			}
		}
		 
	}

	private JButton getButton(int x, Data objData, Logic log, int idClumn) {
		JButton dropButton = new JButton(""); 					//Create new Jbutton object
		dropButton.addActionListener(new ActionListener() { 	//Add listeners to the buttons
			
			public void actionPerformed(ActionEvent arg0) {
          
          if (gameOn==true){									//Check if allow to keep play
        	  	if (log.getArrayPlace()[idClumn] == -1) 		//Check if column is full try again
					return;

				objData.insert(idClumn, player); 				//Drop the coin to the correct cell
				log.initArrayPlace(); 							//Update the highest coins after user's move
				log.initArrayMax(player, log.getArrayMax1());  	//Copy into user matrix all his highest sequence
				
				if (log.getWinner(idClumn, player) == 3) { 		//Check if no one wins
					EndMessagePanel frame = new EndMessagePanel("No winner. Game over!"); //Create game over text 
					frame.setVisible(true);						//Display pop up massage
					gameOn=false;								//Game finish
					printMtrx(objData.getMatrix(), objData.getColumn(), objData.getRows()); //Print the current state of the matrix
					return;										//Exit game loop
					
				}
				else if (log.getWinner(idClumn, player) == 1) { 		//Check if user win
					EndMessagePanel frame = new EndMessagePanel("Winner is user player!");//create the winner text  
					frame.setVisible(true); 					//Display pop up massage
					gameOn=false;								//Game finish
					printMtrx(objData.getMatrix(), objData.getColumn(), objData.getRows()); //Print the current state of the matrix
					return;										//Exit game loop
				}	
				
				player = log.getStepPlayer(player); 			//Change the player to computer

				log.initArrayMax(player, log.getArrayMax2()); 	//Copy into computer matrix all his highest sequence
				int Step = log.getStep();						//Choose random step for computer
				objData.insert(Step, player);					//Insert computer's coin into the chosen cell
				log.initArrayPlace();							//Update the highest coins after computer's move

				
			    if (log.getWinner(Step, player) == 3) { 		//Check if no one wins
					EndMessagePanel frame = new EndMessagePanel("No winner. Game over!"); //Create game over text 
					frame.setVisible(true);						 //Display pop up massage
					gameOn=false;								//Game finish
					printMtrx(objData.getMatrix(), objData.getColumn(), objData.getRows()); //Print the current state of the matrix
					return;										//Exit game loop
					
				}
				else if (log.getWinner(Step, player) == 2) { 	//Check if computer win
					EndMessagePanel frame = new EndMessagePanel("Winner is the Computer!"); //Create the winner text 
					frame.setVisible(true);						//Display pop up massage
					gameOn=false;								//Game finish
					printMtrx(objData.getMatrix(), objData.getColumn(), objData.getRows()); //Print the current state of the matrix
					return;										//Exit game loop
				}
				player = log.getStepPlayer(player); 			//Change the player to user

				printMtrx(objData.getMatrix(), objData.getColumn(), objData.getRows()); //Print the current state of the matrix
          }
			}
			
		});
		dropButton.setBounds(x, 9, 40, 29); 					//Button bounds
		dropButton.setIcon(new ImageIcon("img/arrow.png")); 	//Add button's icon
		return dropButton; 										//Return the current button
		
		
	}



	private JLabel[][] getMtrxLabels(Data objData) { 
		int sizeLabel = 40, space = 5; 														//Set size and space of each square
		int tmp[][] = objData.getMatrix(); 													//Copy matrix to temp matrix
		JLabel[][] mtrxLabel = new JLabel[objData.getRows()][objData.getColumn()]; 			//Set the size of the matrix
		for (int i = 0, y = 40; i < objData.getRows(); i++, y += (sizeLabel + space)) {  	//Run on all rows
			for (int j = 0, x = 30; j < objData.getColumn(); j++, x += (sizeLabel + space)){//Run on all columns
				mtrxLabel[i][j] = getLabel("img/" + tmp[i][j] + ".png", x, y, sizeLabel); 	//Put the icon on the board
			}
		}
		return mtrxLabel; 																	//Return mtrxLabel with the pictures
	}

	//Method for create label's parameters
	private JLabel getLabel(String img, int x, int y, int sizeLabel) { 
		JLabel lbl = new JLabel(new ImageIcon(img)); 				//Create new label
		lbl.setBounds(x, y, sizeLabel, sizeLabel);  				//Set bounds
		lbl.setBorder(BorderFactory.createLineBorder(Color.BLACK)); //Set border and color
		return lbl; 												//return the label with the img icon
	}

	//Method for setting icon's player to the grid
	public void printMtrx(int matrix[][], int column, int rows) { 
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < column; j++) {
				mtrxLabel[i][j].setIcon(new ImageIcon("img/" + matrix[i][j] + ".png")); //Set the correct icon to the current cell
			}
		}
	}
}
