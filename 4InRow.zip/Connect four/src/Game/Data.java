/**
 * Gaby Buchnic & Oved Shalem
 *
 */
package Game;


public class Data {  									//Matrix data
	private int Matrix[][];    							//Define the matrix
	private final int Column = 7;  						//Set number of Column
private final int Rows = 6;  							//Set number of Rows

	public Data() {  									//Ctor for new matrix
		setMatrix();  
	}

	public int[][] getMatrix() {  						//Get status of the matrix
		return Matrix;
	}

	private void setMatrix() {
		Matrix = new int[Rows][Column];  				//Create new matrix 7X6
	}

	public boolean insert(int column, int player) {  	//Insert player/computer coin into the matrix
		if (column < 0 || column >= Column) { 			//Check valid column
			return false;  								//If column not valid return false
		}
		for (int i = (Rows - 1); i >= 0; i--) { 		//Start to drop down the coin
			if (Matrix[i][column] == 0) {  				//Check if cell is free 
				Matrix[i][column] = player; 			//Insert the coin into the free cell
				return true; 							//Case insert succeed return true
			}
		}
		return false;  									//Case insert failed return false
	}

	public int getColumn() {  							//Get the number of Columns
		return Column;
	}

	public int getRows() { 								//Get the number of Rows
		return Rows;
	}

	public void reset() {  								//Method for new matrix(reset)
		setMatrix();
	}

}
